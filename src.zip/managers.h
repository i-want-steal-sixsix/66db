#include "pf/pf_pm.h"

extern PfPageManager sys_page_mgr;