#include "ast.h"

namespace ast {

    std::shared_ptr<ASTNode> parse_tree;

}